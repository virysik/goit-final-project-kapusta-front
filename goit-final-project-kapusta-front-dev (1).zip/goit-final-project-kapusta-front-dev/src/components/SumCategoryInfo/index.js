export { default } from './SumCategoryInfo';
