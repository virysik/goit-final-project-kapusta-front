export { default } from './CategoryInfo';
