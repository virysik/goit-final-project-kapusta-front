export { default } from './ModalDelete';
