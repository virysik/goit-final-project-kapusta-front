export { default } from './Modal';
