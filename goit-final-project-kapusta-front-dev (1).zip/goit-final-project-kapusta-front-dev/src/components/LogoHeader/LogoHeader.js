import styles from './LogoHeader.module.css';

export default function logoHeader() {
  return <span className={styles.link} aria-label="Логотип сайта"></span>;
}
