export { default } from './Svodka';
