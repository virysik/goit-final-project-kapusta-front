export { default } from './GoogleRedirectView';
