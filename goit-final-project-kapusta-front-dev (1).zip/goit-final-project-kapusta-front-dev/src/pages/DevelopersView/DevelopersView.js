import Team from 'components/Team';

export default function DeveloperView() {
  return <Team />;
}