export const expensesOpt = [
  { id: '55', nested: { value: 5000 } },
  { id: 'Говядина', nested: { value: 4500 } },
  { id: 'Курица', nested: { value: 3200 } },
  { id: 'Рыба', nested: { value: 2100 } },
  { id: 'Панини', nested: { value: 1800 } },
  { id: 'Кофе', nested: { value: 1700 } },
  { id: 'Спагетти', nested: { value: 1500 } },
  { id: 'Шоколад', nested: { value: 800 } },
  { id: 'Маслины', nested: { value: 500 } },
  { id: 'Зелень', nested: { value: 300 } },
];

export const incomesOpt = [
  { id: 'ЗП', nested: { value: 25000 } },
  { id: 'Доп.доход', nested: { value: 20000 } },
];
